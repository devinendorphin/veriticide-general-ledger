GROK APP BRIDGE — WHAT TO UPLOAD

Upload grok_app_bridge_free_tier_latest.zip to ChatGPT when you want the results analyzed.
The collector is append-only and resume-safe. Core captures are 1–4; captures 5–8 are optional.
No API calls are made by this notebook.
